
=== FOUND4U SIMULADO ===

Como rodar este projeto em uma sandbox (ex: Lovable AI ou Replit):

1. Suba o conteúdo da pasta 'backend' como projeto Python
2. Execute:
   uvicorn main:app --reload --host 0.0.0.0 --port 8000

3. Em outro navegador, abra o 'index.html' da pasta 'frontend'
4. Teste os botões:
   - Carregar Eventos
   - Usar Token
   - Ver Perfil
   - Enviar Notificação

Requisitos: FastAPI, Uvicorn
Instale com:
   pip install -r requirements.txt

---
Equipe Found4U | Versão Simulada 2025
