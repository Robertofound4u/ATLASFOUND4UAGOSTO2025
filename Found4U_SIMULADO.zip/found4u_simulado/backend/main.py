
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/eventos")
def get_eventos():
    return [
        {"id": 1, "nome": "Festival de Inverno", "data": "2025-08-10", "local": "Praça Central", "lat": -22.90, "lng": -43.18},
        {"id": 2, "nome": "Feira Cultural", "data": "2025-08-12", "local": "Boulevard Sul", "lat": -22.91, "lng": -43.17}
    ]

@app.get("/perfil")
def get_perfil():
    return {"nome": "João", "preferencias": ["esporte", "cultura"], "programas": ["travelpayouts", "multiplus"]}

@app.post("/usar-token")
def usar_token():
    return {"status": "ok", "mensagem": "Token utilizado com sucesso!"}

@app.post("/enviar-notificacao")
def enviar_notificacao():
    return {"status": "ok", "mensagem": "Notificação enviada para usuários no raio definido."}
